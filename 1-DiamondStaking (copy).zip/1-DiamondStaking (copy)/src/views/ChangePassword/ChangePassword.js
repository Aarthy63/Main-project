import React, { Fragment } from "react";

import Header from "../../components/Header/Header";
import Footer from "../../components/Footer/Footer";
import termsBanner from '../../assets/images/termsBanner.png';
import logo from '../../assets/images/logo.png';
 
 const ChangePassword = (props) => {
  
    return (
      <Fragment>
        <Header />
        <div className="Main-section cmsSec" style={{paddingTop:'80px'}}>
            <div className="container container-1200">
                <div className="row justify-content-center">
                    <div className="col-lg-8">
                        <div className="LgnPg">
                            <img src={logo} className="img-fluid d-block mx-auto"/>
                            <h3>Change Password</h3>
                            <div className="form-group">
                                <label>Old Password</label>
                                <input type="password" className="form-control" />
                            </div>
                            <div className="form-group">
                                <label>New Password</label>
                                <input type="password" className="form-control" />
                            </div>
                            <div className="form-group">
                                <label>Confirm Password</label>
                                <input type="password" className="form-control" />
                            </div>
                            <button className="btn LGn-btn">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<Footer />
      </Fragment>
    );
    
    }

export default ChangePassword;