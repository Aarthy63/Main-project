import React, { Fragment, useEffect, useState } from "react";
import { TabContent, TabPane, Nav, NavItem, NavLink
} from 'reactstrap';
import classnames from 'classnames';

import fileUploadIcon from '../../assets/images/file-upload-icon.svg';
import vwTcktArrw from '../../assets/images/vw-tckt-arrw.svg';
import vwtcktInptIcon1 from '../../assets/images/vwtckt-inpt-icon1.svg';
import vwtcktInptIcon2 from '../../assets/images/vwtckt-inpt-icon2.svg';

import ReactDOM from "react-dom";
import {
	BrowserRouter, Navigate, Route, Routes, Link
 } from 'react-router-dom';
 import {
    Accordion,
    AccordionItem,
    AccordionItemHeading,
    AccordionItemButton,
    AccordionItemPanel,
} from 'react-accessible-accordion';

// Demo styles, see 'Styles' section below for some notes on use.
import 'react-accessible-accordion/dist/fancy-example.css';
 
 const DsbPages = (props) => {

    const [activeTab, setActiveTab] = useState('1');
    const toggle = tab => {
        if(activeTab !== tab) setActiveTab(tab);
    }

  
    return (
      <Fragment>

        <div className="DbCntMain">
            <div className="BluBg107 SwapMainSec BluBgLight">
                <div className="SwpHdd mb-4">
                    <h4>Support</h4>
                </div>
                <div className="BluBg0b0 SwpFrMainSec StkFrmMain">
                    <div className="SupprtTbbSec">
                        <nav className="SuprtTbb">
                            <Nav tabs>
                                <NavItem>
                                    <NavLink
                                        className={classnames({ active: activeTab === '1' })}
                                        onClick={() => { toggle('1'); }}
                                    >
                                        Create Ticket
                                    </NavLink>
                                </NavItem>
                                <NavItem>
                                    <NavLink
                                        className={classnames({ active: activeTab === '2' })}
                                        onClick={() => { toggle('2'); }}
                                    >
                                        View Ticket
                                    </NavLink>
                                </NavItem>
                            </Nav>
                            {/* <div className="nav nav-tabs" id="nav-tab" role="tablist">
                                <a className="nav-item nav-link active" id="supprt-tab" data-toggle="tab" href="#supprt1" role="tab" aria-controls="TnsStk1" aria-selected="true">Create Ticket</a>
                                <a className="nav-item nav-link" id="supprt1-tab" data-toggle="tab" href="#supprt2" role="tab" aria-controls="TnsStk2" aria-selected="false">View Ticket</a>
                            </div> */}
                        </nav>
                        <TabContent activeTab={activeTab}>
                            <TabPane tabId="1">
                                <form className="SupprtFrmMain">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="form-group ">
                                                <label for="inputEmail4" className="FrmLbl">Email<span>*</span></label>
                                                <input type="email" className="form-control pl-4" id="inputEmail4" placeholder="Enter Your Email Address" />
                                            </div>
                                            <div className="form-group FrmSlect">
                                                <label for="inputSlct" className="FrmLbl">Category<span>*</span></label>
                                                <select id="inputSlct" className="form-control">
                                                    <option disabled selected>Select Your Category</option>
                                                    <option>Choose...</option>
                                                    <option>...</option>
                                                </select>
                                            </div>
                                            <div className="form-group ">
                                                <label for="input2" className="FrmLbl">Subject<span>*</span></label>
                                                <input type="email" className="form-control pl-4" id="input2" placeholder="Enter  subject" />
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                            <div className="form-group ">
                                                <label for="exampleFormControlTextarea1" className="FrmLbl">Comments<span>*</span></label>
                                                <textarea className="form-control" id="exampleFormControlTextarea1" rows="5"></textarea>
                                            </div>
                                            <div className="form-group ">
                                                <label for="exampleFormControlTextarea1" className="FrmLbl">Add Attachment</label>
                                                <div className="uploadFile">
                                                    <div className="uploadFileFlx">
                                                        <div className="fileCnt">
                                                            <p>Select or drop image here</p>
                                                            <span>Max file size is 100Kb</span>
                                                        </div>
                                                        <div className="fileUpldIcon">
                                                            <img src={fileUploadIcon} alt="" className="img-fluid" />
                                                        </div>
                                                    </div>
                                                    <input type="file" className="inputfile form-control" name="file" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="text-center SwpMainBtn mt-3 mt-md-5">
                                        <button type="submit" className="btn BtnPrimry Btn160-42">Submit</button>
                                    </div>
                                </form>
                            </TabPane>
                            <TabPane tabId="2">
                                <div className="row">
                                    <div className="col-xl-6 col-lg-10 mx-auto">
                                        <div id="main">
                                            <div className="container">
                                                <Accordion id="faq"  >
                                                    <AccordionItem className="card">
                                                        <AccordionItemHeading className="card-header">
                                                            <AccordionItemButton className="btn btn-header-link">
                                                                <span>Ticket ID 01245</span>
                                                                <span className="TcktSts">open <img src={vwTcktArrw} alt="" className="img-fluid" /></span>
                                                            </AccordionItemButton>
                                                        </AccordionItemHeading>
                                                        <AccordionItemPanel className="card-body">
                                                            <div className="VwTkctCnt">
                                                                <h4>Payment Isse</h4>
                                                                <p>Lorem ipsum dolor sit amet consectetur. Eget metus congue ipsum. Lacus turpis feugiat nunc sit etiam. Sodales eu nec non cras eros velit tempus lectus. Eget ut duis nunc velit
                                                                    velit </p>
                                                            </div>
                                                            <div className="TcktInpt mt-3">
                                                                <div className="input-group mb-3">
                                                                    <input type="text" className="form-control" placeholder="Type here...." aria-label="Type here...." aria-describedby="basic-addon2" />
                                                                    <div className="input-group-append">
                                                                        <span className="input-group-text" id="basic-addon2"><button className="btn btn-link"><img src={vwtcktInptIcon1} alt="" className="img-fluid" /></button><button className="btn btn-link"><img src={vwtcktInptIcon2} alt="" className="img-fluid" /></button></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </AccordionItemPanel>
                                                    </AccordionItem>
                                                    <AccordionItem className="card">
                                                        <AccordionItemHeading className="card-header">
                                                            <AccordionItemButton className="btn btn-header-link">
                                                                <span>Ticket ID 01245</span>
                                                                <span className="TcktSts">open <img src={vwTcktArrw} alt="" className="img-fluid" /></span>
                                                            </AccordionItemButton>
                                                        </AccordionItemHeading>
                                                        <AccordionItemPanel className="card-body">
                                                            <div className="VwTkctCnt">
                                                                <h4>Payment Isse</h4>
                                                                <p>Lorem ipsum dolor sit amet consectetur. Eget metus congue ipsum. Lacus turpis feugiat nunc sit etiam. Sodales eu nec non cras eros velit tempus lectus. Eget ut duis nunc velit
                                                                    velit </p>
                                                            </div>
                                                            <div className="TcktInpt mt-3">
                                                                <div className="input-group mb-3">
                                                                    <input type="text" className="form-control" placeholder="Type here...." aria-label="Type here...." aria-describedby="basic-addon2" />
                                                                    <div className="input-group-append">
                                                                        <span className="input-group-text" id="basic-addon2"><button className="btn btn-link"><img src={vwtcktInptIcon1} alt="" className="img-fluid" /></button><button className="btn btn-link"><img src={vwtcktInptIcon2} alt="" className="img-fluid" /></button></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </AccordionItemPanel>
                                                    </AccordionItem>
                                                    <AccordionItem className="card">
                                                        <AccordionItemHeading className="card-header">
                                                            <AccordionItemButton className="btn btn-header-link">
                                                                <span>Ticket ID 01246</span>
                                                                <span className="TcktSts">open <img src={vwTcktArrw} alt="" className="img-fluid" /></span>
                                                            </AccordionItemButton>
                                                        </AccordionItemHeading>
                                                        <AccordionItemPanel className="card-body">
                                                            <div className="VwTkctCnt">
                                                                <h4>Payment Isse</h4>
                                                                <p>Lorem ipsum dolor sit amet consectetur. Eget metus congue ipsum. Lacus turpis feugiat nunc sit etiam. Sodales eu nec non cras eros velit tempus lectus. Eget ut duis nunc velit
                                                                    velit </p>
                                                            </div>
                                                            <div className="TcktInpt mt-3">
                                                                <div className="input-group mb-3">
                                                                    <input type="text" className="form-control" placeholder="Type here...." aria-label="Type here...." aria-describedby="basic-addon2" />
                                                                    <div className="input-group-append">
                                                                        <span className="input-group-text" id="basic-addon2"><button className="btn btn-link"><img src={vwtcktInptIcon1} alt="" className="img-fluid" /></button><button className="btn btn-link"><img src={vwtcktInptIcon2} alt="" className="img-fluid" /></button></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </AccordionItemPanel>
                                                    </AccordionItem>
                                                </Accordion>
                                                {/* <div className="accordion" id="faq">
                                                    <div className="card">
                                                        <div className="card-header" id="faqhead1">
                                                            <a href="#" className="btn btn-header-link" data-toggle="collapse" data-target="#faq1" aria-expanded="true" aria-controls="faq1">
                                                                <span>Ticket ID 01245</span>
                                                                <span className="TcktSts">open <img src={vwTcktArrw} alt="" className="img-fluid" /></span>
                                                            </a>
                                                        </div>
                                                        <div id="faq1" className="collapse show" aria-labelledby="faqhead1" data-parent="#faq">
                                                            <div className="card-body">
                                                                <div className="VwTkctCnt">
                                                                    <h4>Payment Isse</h4>
                                                                    <p>Lorem ipsum dolor sit amet consectetur. Eget metus congue ipsum. Lacus turpis feugiat nunc sit etiam. Sodales eu nec non cras eros velit tempus lectus. Eget ut duis nunc velit
                                                                        velit </p>
                                                                </div>
                                                                <div className="TcktInpt mt-3">
                                                                    <div className="input-group mb-3">
                                                                        <input type="text" className="form-control" placeholder="Type here...." aria-label="Type here...." aria-describedby="basic-addon2" />
                                                                        <div className="input-group-append">
                                                                            <span className="input-group-text" id="basic-addon2"><button className="btn btn-link"><img src={vwtcktInptIcon1} alt="" className="img-fluid" /></button><button className="btn btn-link"><img src={vwtcktInptIcon2} alt="" className="img-fluid" /></button></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="card">
                                                        <div className="card-header" id="faqhead2">
                                                            <a href="#" className="btn btn-header-link collapsed" data-toggle="collapse" data-target="#faq2" aria-expanded="true" aria-controls="faq2"><span>Ticket ID 01245</span>
                                                                <span className="TcktSts">open <img src={vwTcktArrw} alt="" className="img-fluid" /></span></a>
                                                        </div>

                                                        <div id="faq2" className="collapse" aria-labelledby="faqhead2" data-parent="#faq">
                                                            <div className="card-body">
                                                                <div className="VwTkctCnt">
                                                                    <h4>Payment Isse</h4>
                                                                    <p>Lorem ipsum dolor sit amet consectetur. Eget metus congue ipsum. Lacus turpis feugiat nunc sit etiam. Sodales eu nec non cras eros velit tempus lectus. Eget ut duis nunc velit
                                                                        velit </p>
                                                                </div>
                                                                <div className="TcktInpt mt-3">
                                                                    <div className="input-group mb-3">
                                                                        <input type="text" className="form-control" placeholder="Type here...." aria-label="Type here...." aria-describedby="basic-addon2" />
                                                                        <div className="input-group-append">
                                                                            <span className="input-group-text" id="basic-addon2"><button className="btn btn-link"><img src={vwtcktInptIcon1} alt="" className="img-fluid" /></button><button className="btn btn-link"><img src={vwtcktInptIcon2} alt="" className="img-fluid" /></button></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="card">
                                                        <div className="card-header" id="faqhead3">
                                                            <a href="#" className="btn btn-header-link collapsed" data-toggle="collapse" data-target="#faq3" aria-expanded="true" aria-controls="faq3"><span>Ticket ID 01245</span>
                                                                <span className="TcktSts">open <img src={vwTcktArrw} alt="" className="img-fluid" /></span></a>
                                                        </div>

                                                        <div id="faq3" className="collapse" aria-labelledby="faqhead3" data-parent="#faq">
                                                            <div className="card-body">
                                                                <div className="VwTkctCnt">
                                                                    <h4>Payment Isse</h4>
                                                                    <p>Lorem ipsum dolor sit amet consectetur. Eget metus congue ipsum. Lacus turpis feugiat nunc sit etiam. Sodales eu nec non cras eros velit tempus lectus. Eget ut duis nunc velit
                                                                        velit </p>
                                                                </div>
                                                                <div className="TcktInpt mt-3">
                                                                    <div className="input-group mb-3">
                                                                        <input type="text" className="form-control" placeholder="Type here...." aria-label="Type here...." aria-describedby="basic-addon2" />
                                                                        <div className="input-group-append">
                                                                            <span className="input-group-text" id="basic-addon2"><button className="btn btn-link"><img src={vwtcktInptIcon1} alt="" className="img-fluid" /></button><button className="btn btn-link"><img src={vwtcktInptIcon2} alt="" className="img-fluid" /></button></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> */}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </TabPane>
                        </TabContent>
                    </div>
                </div>
            </div>
        </div>
		
      </Fragment>
    );
    
}

export default DsbPages;