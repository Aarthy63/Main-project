import React, { Fragment, useState } from "react";
import * as yup from "yup";
import { useForm } from "react-hook-form";
import Header from "../../components/Header/Header";
import Footer from "../../components/Footer/Footer";
import logo from '../../assets/images/logo.png';
import { yupResolver } from "@hookform/resolvers/yup";

const schema = yup.object().shape({
  email: yup.string().email("Invalid email").required("Email is required"),
});

const ForgotPassword = (props) => {
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [otp, setOtp] = useState("");

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
  });

  const handleSend = () => {
    // You can implement the logic to send the OTP here
    // For now, let's just show the OTP modal
    setShowOtpModal(true);
  };

  const handleVerify = () => {
    // Implement OTP verification logic here
    if (otp === "123456") {
      setShowOtpModal(false);
      // Add logic to navigate to the next step or perform any other action
    } else {
      // Handle incorrect OTP
      alert("Incorrect OTP. Please try again.");
    }
  };

  return (
    <Fragment>
      <Header />
      <div className="Main-section cmsSec" style={{ paddingTop: '80px' }}>
        <div className="container container-1200">
          <div className="row justify-content-center">
            <div className="col-lg-8">
              <div className="LgnPg">
                <img src={logo} className="img-fluid d-block mx-auto" />
                <h3>FORGOT PASSWORD</h3>
                <form onSubmit={handleSubmit(handleSend)}>
                  <div className="form-group">
                    <label>Email</label>
                    <input
                      type="text"
                      className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                      {...register('email')}
                    />
                    <div className="invalid-feedback">{errors.email?.message}</div>
                  </div>
                  <button type="submit" className="btn LGn-btn">
                    Send
                  </button>
                </form>
                <p>
                  Didn’t receive the OTP ?
                  <a href="#" className="ml-2">
                    Resend OTP
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showOtpModal && (
        <div className="modal" style={{ display: "block", background: "rgba(0, 0, 0, 0.5)" }}>
          <div className="modal-content">
            <span className="close" onClick={() => setShowOtpModal(false)}>
              &times;
            </span>
            <h3>Enter OTP</h3>
            <input
              type="text"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              placeholder="Enter OTP"
            />
            <button className="btn LGn-btn" onClick={handleVerify}>
              Verify
            </button>
          </div>
        </div>
      )}

      <Footer />
    </Fragment>
  );
};

export default ForgotPassword;
