import React, { useState, useEffect } from "react";
import Web3 from "web3";
import {ContractABI} from "./ContractABI"; 

const Getaccounts = () => {
  const [address, setAddress] = useState("");
  const [balance, setBalance] = useState(0);
  const [web3, setWeb3] = useState(null);
  const [block, setBlock] = useState();
  const [currentAccount, setCurrentAccount] = useState(null);
  const [myContract, setMyContract] = useState(null); // State to store contract instance
  const [contractAddress, setContractAddress] = useState("0x8c851d1a123ff703bd1f9dabe631b69902df5f97");

  useEffect(() => {
    if (window.ethereum) {
      try {
        console.log("Initializing Web3...");
        const web3Instance = new Web3(window.ethereum);
        setWeb3(web3Instance);
      
        const contractAddress = "0x50d0032257F98FfEE9492452121C9D1C584087d8";
        const contractInstance = new web3Instance.eth.Contract(ContractABI,
             contractAddress);
        setMyContract(contractInstance);
      } catch (error) {
        console.error("Error initializing Web3:", error);
      }
    } else {
      console.error("MetaMask not installed.");
    }
  }, []);

  const handleAllActions = async () => {
    try {
      console.log("Requesting accounts...");
      const accounts = await window.ethereum.request({
        method: "eth_requestAccounts"
      });
      console.log("Connected accounts:", accounts);
      setAddress(accounts);
      setCurrentAccount(accounts[0]);

      if (accounts.length > 0) {
        web3.eth.getBalance(accounts[0]).then((balance) => {
          const balanceInEther = web3.utils.fromWei(balance, "ether");
          console.log("Balance in Ether:", balanceInEther);
          setBalance(balanceInEther);
        });
      } else {
        console.error("MetaMask not connected. Please connect your wallet.");
      }

      console.log("Switching network...");
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [
          {
            chainId: "0x38"
          }
        ]
      });
      console.log("Network switched successfully.");

      console.log("Fetching block number...");
      const blockNumber = await web3.eth.getBlockNumber();
      console.log("Block number:", blockNumber);
      setBlock(blockNumber);

      if (!currentAccount) {
        alert("Please connect your wallet first.");
        return;
      }

      console.log("Interacting with the contract...");
      const contractResult = await interactWithContract();
      console.log("Contract interaction result:", contractResult);
    } catch (error) {
      console.error("Error in handleAllActions:", error);
    }
  };

  const interactWithContract = async () => {
    if (!currentAccount) {
      alert("Please connect your wallet first.");
      return;
    }
    // Replace with your logic to interact with the contract on BscScan
    window.open(`https://bscscan.com/token/${contractAddress}#code`, '_blank');
  };

  return (
    <div className="App mt-5 vh-100">
      <div className="text-center">
        <h4 className="form-label">
          <strong>Address: </strong>
          {address}
        </h4>
        <h4 className="form-label">
          <strong>Balance: </strong>
          {balance}
        </h4>
        <button onClick={handleAllActions} className="btn btn-primary">
          Connect, Switch Network, Get Block, Interact with Contract
        </button>
        <br />
        <br />
        {/* Displaying Block Number */}
        {block && (
          <>
            <p><strong>Block Number:</strong> {parseInt(block)}</p>
          </>
        )}
        <br />
        <p>Connected Account: {currentAccount || "Not connected"}</p>
      </div>
    </div>
  );
};

export default Getaccounts;
